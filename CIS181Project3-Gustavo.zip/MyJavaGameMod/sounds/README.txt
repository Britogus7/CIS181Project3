Any WAV sounds must be in the following
format to work:
22050 hz, 16 bit, mono

On a windows machine use Sound Recorder to convert to these settings.